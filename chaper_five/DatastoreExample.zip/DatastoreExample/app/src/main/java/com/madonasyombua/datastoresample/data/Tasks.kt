package com.madonasyombua.datastoresample.data

data class Tasks(
    val firstTask: String,
    val secondTask: String,
    val thirdTask: String
)