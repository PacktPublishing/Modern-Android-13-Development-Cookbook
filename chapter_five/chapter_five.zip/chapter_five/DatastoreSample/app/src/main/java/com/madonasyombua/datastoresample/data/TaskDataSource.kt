package com.madonasyombua.datastoresample.data

enum class TaskDataSource {
    PREFERENCES_DATA_STORE,
    PROTO_DATA_STORE
}